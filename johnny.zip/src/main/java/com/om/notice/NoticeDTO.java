package com.om.notice;

import com.om.board.BoardDTO;

public class NoticeDTO extends BoardDTO{

}
